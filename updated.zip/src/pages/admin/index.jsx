// import { useEffect, useState } from "react";
// import { supabase } from "@/integrations/supabase/client";
// import { Button } from "@/components/ui/button";
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Textarea } from "@/components/ui/textarea";
// import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
// import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
// import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
// import { toast } from "sonner";
// import { ArrowLeft, Plus, Trash2, Users, BookOpen, HelpCircle, Award, Edit, Shield, ShieldOff } from "lucide-react";
// import { useRouter } from "next/navigation";

// const Admin = () => {
//   const navigate = useRouter();
//   const [isAdmin, setIsAdmin] = useState(false);
//   const [loading, setLoading] = useState(true);
//   const [lessons, setLessons] = useState([]);
//   const [users, setUsers] = useState([]);
//   const [editingLesson, setEditingLesson] = useState(null);
//   const [stats, setStats] = useState({
//     totalUsers: 0,
//     totalLessons: 0,
//     totalQuestions: 0,
//     totalAchievements: 0,
//   });
 
//   const [newLesson, setNewLesson] = useState({
//     title: "",
//     description: "",
//     difficulty: "beginner",
//     xp_reward: 10,
//     order_index: 0,
//   });
//   useEffect(() => {
//     checkAdminStatus();
//   }, []);
//   const checkAdminStatus = async () => {
//     try {
//       const { data: { user } } = await supabase.auth.getUser();
//       if (!user) {
//         navigate.push("/auth");
//         return;
//       }
//       const { data: roles } = await supabase
//         .from("user_roles")
//         .select("role")
//         .eq("user_id", user.id)
//         .eq("role", "admin");
//       if (!roles || roles.length === 0) {
//         toast.error("Access denied. Admin only.");
//         navigate.push("/dashboard");
//         return;
//       }
//       setIsAdmin(true);
//       await Promise.all([fetchLessons(), fetchStats(), fetchUsers()]);
//     } catch (error) {
//       toast.error(error.message);
//       navigate.push("/dashboard");
//     } finally {
//       setLoading(false);
//     }
//   };
//   const fetchStats = async () => {
//     const [usersResult, lessonsResult, questionsResult, achievementsResult] = await Promise.all([
//       supabase.from("profiles").select("id", { count: 'exact', head: true }),
//       supabase.from("lessons").select("id", { count: 'exact', head: true }),
//       supabase.from("questions").select("id", { count: 'exact', head: true }),
//       supabase.from("achievements").select("id", { count: 'exact', head: true }),
//     ]);
//     setStats({
//       totalUsers: usersResult.count || 0,
//       totalLessons: lessonsResult.count || 0,
//       totalQuestions: questionsResult.count || 0,
//       totalAchievements: achievementsResult.count || 0,
//     });
//   };
//   const fetchLessons = async () => {
//     const { data } = await supabase
//       .from("lessons")
//       .select("*")
//       .order("order_index");
//     if (data) {
//       setLessons(data);
//       setNewLesson(prev => ({ ...prev, order_index: data.length }));
//     }
//   };
//   const fetchUsers = async () => {
//     const { data: profiles } = await supabase
//       .from("profiles")
//       .select("id, username, display_name, total_xp, created_at")
//       .order("created_at", { ascending: false });
//     if (profiles) {
//       const { data: roles } = await supabase
//         .from("user_roles")
//         .select("user_id, role");
//       const usersWithRoles = profiles.map(profile => ({
//         ...profile,
//         role: roles?.find(r => r.user_id === profile.id)?.role || null,
//       }));
//       setUsers(usersWithRoles);
//     }
//   };
//   const handleCreateLesson = async (e) => {
//     e.preventDefault();
   
//     try {
//       const { error } = await supabase
//         .from("lessons")
//         .insert([newLesson]);
//       if (error) throw error;
//       toast.success("Lesson created successfully! 🎉");
//       setNewLesson({
//         title: "",
//         description: "",
//         difficulty: "beginner",
//         xp_reward: 10,
//         order_index: lessons.length,
//       });
//       fetchLessons();
//     } catch (error) {
//       toast.error(error.message);
//     }
//   };
//   const handleUpdateLesson = async (e) => {
//     e.preventDefault();
//     if (!editingLesson) return;
//     try {
//       const { error } = await supabase
//         .from("lessons")
//         .update({
//           title: editingLesson.title,
//           description: editingLesson.description,
//           difficulty: editingLesson.difficulty,
//           xp_reward: editingLesson.xp_reward,
//           order_index: editingLesson.order_index,
//         })
//         .eq("id", editingLesson.id);
//       if (error) throw error;
//       toast.success("Lesson updated successfully! ✅");
//       setEditingLesson(null);
//       fetchLessons();
//     } catch (error) {
//       toast.error(error.message);
//     }
//   };
//   const handleDeleteLesson = async (id) => {
//     if (!confirm("Are you sure you want to delete this lesson?")) return;
//     try {
//       const { error } = await supabase
//         .from("lessons")
//         .delete()
//         .eq("id", id);
//       if (error) throw error;
//       toast.success("Lesson deleted successfully!");
//       fetchLessons();
//     } catch (error) {
//       toast.error(error.message);
//     }
//   };
//   const handleToggleAdmin = async (userId, currentRole) => {
//     try {
//       if (currentRole === "admin") {
//         const { error } = await supabase
//           .from("user_roles")
//           .delete()
//           .eq("user_id", userId)
//           .eq("role", "admin");
//         if (error) throw error;
//         toast.success("Admin role removed! 🔓");
//       } else {
//         const { error } = await supabase
//           .from("user_roles")
//           .insert([{ user_id: userId, role: "admin" }]);
//         if (error) throw error;
//         toast.success("Admin role granted! 🛡️");
//       }
//       fetchUsers();
//     } catch (error) {
//       toast.error(error.message);
//     }
//   };
//   if (loading) {
//     return (
//       <div className="min-h-screen flex items-center justify-center">
//         <div className="text-lg animate-pulse">Loading... ⏳</div>
//       </div>
//     );
//   }
//   if (!isAdmin) return null;
//   return (
//     <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-secondary/5">
//       <div className="container max-w-6xl mx-auto px-4 py-8">
//         <div className="animate-fade-in">
//           <Button
//             variant="ghost"
//             onClick={() => navigate.push("/dashboard")}
//             className="mb-4 hover:scale-105 transition-transform"
//           >
//             <ArrowLeft className="w-4 h-4 mr-2" />
//             Back to Dashboard
//           </Button>
//           <h1 className="text-4xl font-bold mb-2 bg-gradient-primary bg-clip-text text-transparent">
//             Admin Dashboard 👨‍💼
//           </h1>
//           <p className="text-muted-foreground mb-8">Manage your learning platform</p>
//           {/* Stats Grid */}
//           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
//             <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-primary/50">
//               <CardHeader className="pb-3">
//                 <CardTitle className="text-sm font-medium flex items-center gap-2">
//                   <Users className="w-4 h-4 text-primary" />
//                   Total Users
//                 </CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="text-3xl font-bold text-primary">{stats.totalUsers} 👥</div>
//               </CardContent>
//             </Card>
//             <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-success/50" style={{ animationDelay: '0.1s' }}>
//               <CardHeader className="pb-3">
//                 <CardTitle className="text-sm font-medium flex items-center gap-2">
//                   <BookOpen className="w-4 h-4 text-success" />
//                   Total Lessons
//                 </CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="text-3xl font-bold text-success">{stats.totalLessons} 📚</div>
//               </CardContent>
//             </Card>
//             <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-secondary/50" style={{ animationDelay: '0.2s' }}>
//               <CardHeader className="pb-3">
//                 <CardTitle className="text-sm font-medium flex items-center gap-2">
//                   <HelpCircle className="w-4 h-4 text-secondary" />
//                   Total Questions
//                 </CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="text-3xl font-bold text-secondary">{stats.totalQuestions} ❓</div>
//               </CardContent>
//             </Card>
//             <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-accent/50" style={{ animationDelay: '0.3s' }}>
//               <CardHeader className="pb-3">
//                 <CardTitle className="text-sm font-medium flex items-center gap-2">
//                   <Award className="w-4 h-4 text-accent" />
//                   Achievements
//                 </CardTitle>
//               </CardHeader>
//               <CardContent>
//                 <div className="text-3xl font-bold text-accent">{stats.totalAchievements} 🏆</div>
//               </CardContent>
//             </Card>
//           </div>
//           {/* Tabs for Lessons and Users */}
//           <Tabs defaultValue="lessons" className="space-y-6">
//             <TabsList className="grid w-full grid-cols-2 max-w-md">
//               <TabsTrigger value="lessons" className="flex items-center gap-2">
//                 <BookOpen className="w-4 h-4" /> Lessons
//               </TabsTrigger>
//               <TabsTrigger value="users" className="flex items-center gap-2">
//                 <Users className="w-4 h-4" /> Users
//               </TabsTrigger>
//             </TabsList>
//             <TabsContent value="lessons" className="space-y-6">
//               {/* Create Lesson Form */}
//               <Card className="animate-scale-in border-2">
//                 <CardHeader className="bg-gradient-primary text-primary-foreground rounded-t-lg">
//                   <CardTitle className="flex items-center gap-2">
//                     <span className="text-2xl">➕</span> Create New Lesson
//                   </CardTitle>
//                   <CardDescription className="text-primary-foreground/90">
//                     Add a new Hausa language lesson
//                   </CardDescription>
//                 </CardHeader>
//                 <CardContent className="pt-6">
//                   <form onSubmit={handleCreateLesson} className="space-y-4">
//                     <div>
//                       <Label htmlFor="title">Title</Label>
//                       <Input
//                         id="title"
//                         value={newLesson.title}
//                         onChange={(e) => setNewLesson({ ...newLesson, title: e.target.value })}
//                         required
//                       />
//                     </div>
                   
//                     <div>
//                       <Label htmlFor="description">Description</Label>
//                       <Textarea
//                         id="description"
//                         value={newLesson.description}
//                         onChange={(e) => setNewLesson({ ...newLesson, description: e.target.value })}
//                       />
//                     </div>
//                     <div className="grid grid-cols-2 gap-4">
//                       <div>
//                         <Label htmlFor="difficulty">Difficulty</Label>
//                         <Select
//                           value={newLesson.difficulty}
//                           onValueChange={(value) =>
//                             setNewLesson({ ...newLesson, difficulty: value })
//                           }
//                         >
//                           <SelectTrigger>
//                             <SelectValue />
//                           </SelectTrigger>
//                           <SelectContent>
//                             <SelectItem value="beginner">Beginner</SelectItem>
//                             <SelectItem value="intermediate">Intermediate</SelectItem>
//                             <SelectItem value="advanced">Advanced</SelectItem>
//                           </SelectContent>
//                         </Select>
//                       </div>
//                       <div>
//                         <Label htmlFor="xp_reward">XP Reward</Label>
//                         <Input
//                           id="xp_reward"
//                           type="number"
//                           value={newLesson.xp_reward}
//                           onChange={(e) => setNewLesson({ ...newLesson, xp_reward: parseInt(e.target.value) })}
//                           required
//                         />
//                       </div>
//                     </div>
//                     <Button type="submit" className="w-full hover:scale-105 transition-transform bg-gradient-primary">
//                       <Plus className="w-4 h-4 mr-2" />
//                       Create Lesson 🚀
//                     </Button>
//                   </form>
//                 </CardContent>
//               </Card>
//               {/* Existing Lessons */}
//               <Card className="animate-scale-in border-2">
//                 <CardHeader className="bg-gradient-secondary text-secondary-foreground rounded-t-lg">
//                   <CardTitle className="flex items-center gap-2">
//                     <span className="text-2xl">📚</span> Manage Lessons
//                   </CardTitle>
//                   <CardDescription className="text-secondary-foreground/90">
//                     View, edit and manage existing lessons
//                   </CardDescription>
//                 </CardHeader>
//                 <CardContent className="pt-6">
//                   <div className="space-y-4">
//                     {lessons.map((lesson, index) => (
//                       <div
//                         key={lesson.id}
//                         className="flex items-center justify-between p-4 border-2 rounded-lg hover:bg-muted/50 transition-all hover:scale-[1.01] animate-fade-in hover:border-primary/50"
//                         style={{ animationDelay: `${index * 0.05}s` }}
//                       >
//                         <div className="flex-1">
//                           <h3 className="font-bold">{lesson.title}</h3>
//                           <p className="text-sm text-muted-foreground">{lesson.description}</p>
//                           <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
//                             <span>Difficulty: {lesson.difficulty}</span>
//                             <span>XP: {lesson.xp_reward}</span>
//                             <span>Order: {lesson.order_index}</span>
//                           </div>
//                         </div>
//                         <div className="flex gap-2">
//                           <Dialog>
//                             <DialogTrigger asChild>
//                               <Button
//                                 variant="outline"
//                                 size="icon"
//                                 onClick={() => setEditingLesson(lesson)}
//                                 className="hover:scale-110 transition-transform"
//                               >
//                                 <Edit className="w-4 h-4" />
//                               </Button>
//                             </DialogTrigger>
//                             <DialogContent>
//                               <DialogHeader>
//                                 <DialogTitle>Edit Lesson ✏️</DialogTitle>
//                                 <DialogDescription>
//                                   Update lesson details
//                                 </DialogDescription>
//                               </DialogHeader>
//                               {editingLesson && (
//                                 <form onSubmit={handleUpdateLesson} className="space-y-4">
//                                   <div>
//                                     <Label>Title</Label>
//                                     <Input
//                                       value={editingLesson.title}
//                                       onChange={(e) => setEditingLesson({ ...editingLesson, title: e.target.value })}
//                                       required
//                                     />
//                                   </div>
//                                   <div>
//                                     <Label>Description</Label>
//                                     <Textarea
//                                       value={editingLesson.description || ""}
//                                       onChange={(e) => setEditingLesson({ ...editingLesson, description: e.target.value })}
//                                     />
//                                   </div>
//                                   <div className="grid grid-cols-2 gap-4">
//                                     <div>
//                                       <Label>Difficulty</Label>
//                                       <Select
//                                         value={editingLesson.difficulty}
//                                         onValueChange={(value) => setEditingLesson({ ...editingLesson, difficulty: value })}
//                                       >
//                                         <SelectTrigger>
//                                           <SelectValue />
//                                         </SelectTrigger>
//                                         <SelectContent>
//                                           <SelectItem value="beginner">Beginner</SelectItem>
//                                           <SelectItem value="intermediate">Intermediate</SelectItem>
//                                           <SelectItem value="advanced">Advanced</SelectItem>
//                                         </SelectContent>
//                                       </Select>
//                                     </div>
//                                     <div>
//                                       <Label>XP Reward</Label>
//                                       <Input
//                                         type="number"
//                                         value={editingLesson.xp_reward}
//                                         onChange={(e) => setEditingLesson({ ...editingLesson, xp_reward: parseInt(e.target.value) })}
//                                         required
//                                       />
//                                     </div>
//                                   </div>
//                                   <div>
//                                     <Label>Order Index</Label>
//                                     <Input
//                                       type="number"
//                                       value={editingLesson.order_index}
//                                       onChange={(e) => setEditingLesson({ ...editingLesson, order_index: parseInt(e.target.value) })}
//                                       required
//                                     />
//                                   </div>
//                                   <Button type="submit" className="w-full bg-gradient-primary">
//                                     Save Changes ✅
//                                   </Button>
//                                 </form>
//                               )}
//                             </DialogContent>
//                           </Dialog>
//                           <Button
//                             variant="destructive"
//                             size="icon"
//                             onClick={() => handleDeleteLesson(lesson.id)}
//                             className="hover:scale-110 transition-transform"
//                           >
//                             <Trash2 className="w-4 h-4" />
//                           </Button>
//                         </div>
//                       </div>
//                     ))}
//                     {lessons.length === 0 && (
//                       <p className="text-center text-muted-foreground py-8 animate-bounce-in">
//                         No lessons yet. Create your first lesson above! 🎓
//                       </p>
//                     )}
//                   </div>
//                 </CardContent>
//               </Card>
//             </TabsContent>
//             <TabsContent value="users">
//               <Card className="animate-scale-in border-2">
//                 <CardHeader className="bg-gradient-primary text-primary-foreground rounded-t-lg">
//                   <CardTitle className="flex items-center gap-2">
//                     <span className="text-2xl">👥</span> Manage Users
//                   </CardTitle>
//                   <CardDescription className="text-primary-foreground/90">
//                     View users and manage admin roles
//                   </CardDescription>
//                 </CardHeader>
//                 <CardContent className="pt-6">
//                   <Table>
//                     <TableHeader>
//                       <TableRow>
//                         <TableHead>Username</TableHead>
//                         <TableHead>Display Name</TableHead>
//                         <TableHead>XP</TableHead>
//                         <TableHead>Role</TableHead>
//                         <TableHead>Joined</TableHead>
//                         <TableHead>Actions</TableHead>
//                       </TableRow>
//                     </TableHeader>
//                     <TableBody>
//                       {users.map((user) => (
//                         <TableRow key={user.id} className="hover:bg-muted/50">
//                           <TableCell className="font-medium">{user.username}</TableCell>
//                           <TableCell>{user.display_name || "-"}</TableCell>
//                           <TableCell>{user.total_xp} ⭐</TableCell>
//                           <TableCell>
//                             {user.role === "admin" ? (
//                               <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
//                                 <Shield className="w-3 h-3" /> Admin
//                               </span>
//                             ) : (
//                               <span className="text-muted-foreground text-xs">User</span>
//                             )}
//                           </TableCell>
//                           <TableCell className="text-muted-foreground text-sm">
//                             {new Date(user.created_at).toLocaleDateString()}
//                           </TableCell>
//                           <TableCell>
//                             <Button
//                               variant={user.role === "admin" ? "destructive" : "outline"}
//                               size="sm"
//                               onClick={() => handleToggleAdmin(user.id, user.role)}
//                               className="hover:scale-105 transition-transform"
//                             >
//                               {user.role === "admin" ? (
//                                 <>
//                                   <ShieldOff className="w-4 h-4 mr-1" /> Remove Admin
//                                 </>
//                               ) : (
//                                 <>
//                                   <Shield className="w-4 h-4 mr-1" /> Make Admin
//                                 </>
//                               )}
//                             </Button>
//                           </TableCell>
//                         </TableRow>
//                       ))}
//                     </TableBody>
//                   </Table>
//                   {users.length === 0 && (
//                     <p className="text-center text-muted-foreground py-8">
//                       No users found 🔍
//                     </p>
//                   )}
//                 </CardContent>
//               </Card>
//             </TabsContent>
//           </Tabs>
//         </div>
//       </div>
//     </div>
//   );
// };
// export default Admin;

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { ArrowLeft, Plus, Trash2, Users, BookOpen, HelpCircle, Award, Edit, Shield, ShieldOff } from "lucide-react";

const Admin = () => {
  const navigate = useRouter();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lessons, setLessons] = useState([]);
  const [users, setUsers] = useState([]);
  const [editingLesson, setEditingLesson] = useState(null);
  const [editingQuestions, setEditingQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState({
    question_text: "",
    question_type: "multiple_choice",
    correct_answer: "",
    options: "",
    translation_hint: "",
    order_index: 1,
  });
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalLessons: 0,
    totalQuestions: 0,
    totalAchievements: 0,
  });
 
  const [newLesson, setNewLesson] = useState({
    title: "",
    description: "",
    difficulty: "beginner",
    xp_reward: 10,
    order_index: 0,
  });
  useEffect(() => {
    checkAdminStatus();
  }, []);
  const checkAdminStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate.push("/auth");
        return;
      }
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin");
      if (!roles || roles.length === 0) {
        toast.error("Access denied. Admin only.");
        navigate.push("/dashboard");
        return;
      }
      setIsAdmin(true);
      await Promise.all([fetchLessons(), fetchStats(), fetchUsers()]);
    } catch (error) {
      toast.error(error.message);
      navigate.push("/dashboard");
    } finally {
      setLoading(false);
    }
  };
  const fetchStats = async () => {
    const [usersResult, lessonsResult, questionsResult, achievementsResult] = await Promise.all([
      supabase.from("profiles").select("id", { count: 'exact', head: true }),
      supabase.from("lessons").select("id", { count: 'exact', head: true }),
      supabase.from("questions").select("id", { count: 'exact', head: true }),
      supabase.from("achievements").select("id", { count: 'exact', head: true }),
    ]);
    setStats({
      totalUsers: usersResult.count || 0,
      totalLessons: lessonsResult.count || 0,
      totalQuestions: questionsResult.count || 0,
      totalAchievements: achievementsResult.count || 0,
    });
  };
  const fetchLessons = async () => {
    const { data } = await supabase
      .from("lessons")
      .select("*")
      .order("order_index");
    if (data) {
      setLessons(data);
      setNewLesson(prev => ({ ...prev, order_index: data.length }));
    }
  };
  const fetchUsers = async () => {
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, username, display_name, total_xp, created_at")
      .order("created_at", { ascending: false });
    if (profiles) {
      const { data: roles } = await supabase
        .from("user_roles")
        .select("user_id, role");
      const usersWithRoles = profiles.map(profile => ({
        ...profile,
        role: roles?.find(r => r.user_id === profile.id)?.role || null,
      }));
      setUsers(usersWithRoles);
    }
  };
  const fetchQuestionsForLesson = async (lessonId) => {
    const { data } = await supabase
      .from("questions")
      .select("*")
      .eq("lesson_id", lessonId)
      .order("order_index");
    if (data) {
      setEditingQuestions(data);
      setNewQuestion(prev => ({ ...prev, order_index: data.length + 1 }));
    }
  };
  const handleCreateLesson = async (e) => {
    e.preventDefault();
   
    try {
      const { error } = await supabase
        .from("lessons")
        .insert([newLesson]);
      if (error) throw error;
      toast.success("Lesson created successfully! 🎉");
      setNewLesson({
        title: "",
        description: "",
        difficulty: "beginner",
        xp_reward: 10,
        order_index: lessons.length,
      });
      fetchLessons();
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleUpdateLesson = async (e) => {
    e.preventDefault();
    if (!editingLesson) return;
    try {
      const { error } = await supabase
        .from("lessons")
        .update({
          title: editingLesson.title,
          description: editingLesson.description,
          difficulty: editingLesson.difficulty,
          xp_reward: editingLesson.xp_reward,
          order_index: editingLesson.order_index,
        })
        .eq("id", editingLesson.id);
      if (error) throw error;
      toast.success("Lesson updated successfully! ✅");
      setEditingLesson(null);
      setEditingQuestions([]);
      fetchLessons();
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleDeleteLesson = async (id) => {
    if (!confirm("Are you sure you want to delete this lesson?")) return;
    try {
      const { error } = await supabase
        .from("lessons")
        .delete()
        .eq("id", id);
      if (error) throw error;
      toast.success("Lesson deleted successfully!");
      fetchLessons();
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleCreateQuestion = async (e) => {
    e.preventDefault();
    if (!editingLesson) return;
    try {
      const options = newQuestion.options.trim() ? JSON.parse(newQuestion.options) : null;
      const { error } = await supabase
        .from("questions")
        .insert([{
          lesson_id: editingLesson.id,
          question_text: newQuestion.question_text,
          question_type: newQuestion.question_type,
          correct_answer: newQuestion.correct_answer,
          options: options,
          translation_hint: newQuestion.translation_hint,
          order_index: newQuestion.order_index,
        }]);
      if (error) throw error;
      toast.success("Question created successfully! ✅");
      setNewQuestion({
        question_text: "",
        question_type: "multiple_choice",
        correct_answer: "",
        options: "",
        translation_hint: "",
        order_index: editingQuestions.length + 1,
      });
      fetchQuestionsForLesson(editingLesson.id);
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleDeleteQuestion = async (questionId) => {
    if (!confirm("Are you sure you want to delete this question?")) return;
    try {
      const { error } = await supabase
        .from("questions")
        .delete()
        .eq("id", questionId);
      if (error) throw error;
      toast.success("Question deleted successfully!");
      fetchQuestionsForLesson(editingLesson.id);
    } catch (error) {
      toast.error(error.message);
    }
  };
  const handleToggleAdmin = async (userId, currentRole) => {
    try {
      if (currentRole === "admin") {
        const { error } = await supabase
          .from("user_roles")
          .delete()
          .eq("user_id", userId)
          .eq("role", "admin");
        if (error) throw error;
        toast.success("Admin role removed! 🔓");
      } else {
        const { error } = await supabase
          .from("user_roles")
          .insert([{ user_id: userId, role: "admin" }]);
        if (error) throw error;
        toast.success("Admin role granted! 🛡️");
      }
      fetchUsers();
    } catch (error) {
      toast.error(error.message);
    }
  };
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg animate-pulse">Loading... ⏳</div>
      </div>
    );
  }
  if (!isAdmin) return null;
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-secondary/5">
      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="animate-fade-in">
          <Button
            variant="ghost"
            onClick={() => navigate.push("/dashboard")}
            className="mb-4 hover:scale-105 transition-transform"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-primary bg-clip-text text-transparent">
            Admin Dashboard 👨‍💼
          </h1>
          <p className="text-muted-foreground mb-8">Manage your learning platform</p>
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-primary/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Users className="w-4 h-4 text-primary" />
                  Total Users
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">{stats.totalUsers} 👥</div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-success/50" style={{ animationDelay: '0.1s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-success" />
                  Total Lessons
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-success">{stats.totalLessons} 📚</div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-secondary/50" style={{ animationDelay: '0.2s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-secondary" />
                  Total Questions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-secondary">{stats.totalQuestions} ❓</div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-accent/50" style={{ animationDelay: '0.3s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Award className="w-4 h-4 text-accent" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-accent">{stats.totalAchievements} 🏆</div>
              </CardContent>
            </Card>
          </div>
          {/* Tabs for Lessons and Users */}
          <Tabs defaultValue="lessons" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 max-w-md">
              <TabsTrigger value="lessons" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" /> Lessons
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="w-4 h-4" /> Users
              </TabsTrigger>
            </TabsList>
            <TabsContent value="lessons" className="space-y-6">
              {/* Create Lesson Form */}
              <Card className="animate-scale-in border-2">
                <CardHeader className="bg-gradient-primary text-primary-foreground rounded-t-lg">
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">➕</span> Create New Lesson
                  </CardTitle>
                  <CardDescription className="text-primary-foreground/90">
                    Add a new Hausa language lesson
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <form onSubmit={handleCreateLesson} className="space-y-4">
                    <div>
                      <Label htmlFor="title">Title</Label>
                      <Input
                        id="title"
                        value={newLesson.title}
                        onChange={(e) => setNewLesson({ ...newLesson, title: e.target.value })}
                        required
                      />
                    </div>
                   
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newLesson.description}
                        onChange={(e) => setNewLesson({ ...newLesson, description: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="difficulty">Difficulty</Label>
                        <Select
                          value={newLesson.difficulty}
                          onValueChange={(value) =>
                            setNewLesson({ ...newLesson, difficulty: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="xp_reward">XP Reward</Label>
                        <Input
                          id="xp_reward"
                          type="number"
                          value={newLesson.xp_reward}
                          onChange={(e) => setNewLesson({ ...newLesson, xp_reward: parseInt(e.target.value) })}
                          required
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full hover:scale-105 transition-transform bg-gradient-primary">
                      <Plus className="w-4 h-4 mr-2" />
                      Create Lesson 🚀
                    </Button>
                  </form>
                </CardContent>
              </Card>
              {/* Existing Lessons */}
              <Card className="animate-scale-in border-2">
                <CardHeader className="bg-gradient-secondary text-secondary-foreground rounded-t-lg">
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">📚</span> Manage Lessons
                  </CardTitle>
                  <CardDescription className="text-secondary-foreground/90">
                    View, edit and manage existing lessons
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    {lessons.map((lesson, index) => (
                      <div
                        key={lesson.id}
                        className="flex items-center justify-between p-4 border-2 rounded-lg hover:bg-muted/50 transition-all hover:scale-[1.01] animate-fade-in hover:border-primary/50"
                        style={{ animationDelay: `${index * 0.05}s` }}
                      >
                        <div className="flex-1">
                          <h3 className="font-bold">{lesson.title}</h3>
                          <p className="text-sm text-muted-foreground">{lesson.description}</p>
                          <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                            <span>Difficulty: {lesson.difficulty}</span>
                            <span>XP: {lesson.xp_reward}</span>
                            <span>Order: {lesson.order_index}</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => setEditingLesson(lesson)}
                                className="hover:scale-110 transition-transform"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                           <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto sm:max-h-[85vh]">
  <DialogHeader>
    <DialogTitle>Edit Lesson ✏️</DialogTitle>
    <DialogDescription>
      Update lesson details and manage questions
    </DialogDescription>
  </DialogHeader>
  {editingLesson && (
    <div className="space-y-6 p-0">
      <form onSubmit={handleUpdateLesson} className="space-y-4">
        <div>
          <Label>Title</Label>
          <Input
            value={editingLesson.title}
            onChange={(e) => setEditingLesson({ ...editingLesson, title: e.target.value })}
            required
          />
        </div>
        <div>
          <Label>Description</Label>
          <Textarea
            value={editingLesson.description || ""}
            onChange={(e) => setEditingLesson({ ...editingLesson, description: e.target.value })}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label>Difficulty</Label>
            <Select
              value={editingLesson.difficulty}
              onValueChange={(value) => setEditingLesson({ ...editingLesson, difficulty: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>XP Reward</Label>
            <Input
              type="number"
              value={editingLesson.xp_reward}
              onChange={(e) => setEditingLesson({ ...editingLesson, xp_reward: parseInt(e.target.value) })}
              required
            />
          </div>
        </div>
        <div>
          <Label>Order Index</Label>
          <Input
            type="number"
            value={editingLesson.order_index}
            onChange={(e) => setEditingLesson({ ...editingLesson, order_index: parseInt(e.target.value) })}
            required
          />
        </div>
        <Button type="submit" className="w-full bg-gradient-primary">
          Save Lesson Changes ✅
        </Button>
      </form>
      {/* Questions Management */}
      <div>
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <HelpCircle className="w-5 h-5" />
          Manage Questions
        </h3>
        {/* Add New Question Form */}
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="text-sm">Add New Question</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateQuestion} className="space-y-4">
              <div>
                <Label>Question Text</Label>
                <Textarea
                  value={newQuestion.question_text}
                  onChange={(e) => setNewQuestion({ ...newQuestion, question_text: e.target.value })}
                  placeholder="Enter the question..."
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Question Type</Label>
                  <Select
                    value={newQuestion.question_type}
                    onValueChange={(value) => setNewQuestion({ ...newQuestion, question_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                      <SelectItem value="translation">Translation</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Order Index</Label>
                  <Input
                    type="number"
                    value={newQuestion.order_index}
                    onChange={(e) => setNewQuestion({ ...newQuestion, order_index: parseInt(e.target.value) })}
                    required
                  />
                </div>
              </div>
              <div>
                <Label>Correct Answer</Label>
                <Input
                  value={newQuestion.correct_answer}
                  onChange={(e) => setNewQuestion({ ...newQuestion, correct_answer: e.target.value })}
                  placeholder="Enter the correct answer"
                  required
                />
              </div>
              <div>
                <Label>Options (JSON array, e.g. ["A", "B", "C", "D"])</Label>
                <Textarea
                  value={newQuestion.options}
                  onChange={(e) => setNewQuestion({ ...newQuestion, options: e.target.value })}
                  placeholder='["Option 1", "Option 2", "Option 3"]'
                />
              </div>
              <div>
                <Label>Translation Hint (optional)</Label>
                <Input
                  value={newQuestion.translation_hint}
                  onChange={(e) => setNewQuestion({ ...newQuestion, translation_hint: e.target.value })}
                  placeholder="Optional hint for translation questions"
                />
              </div>
              <Button type="submit" className="w-full bg-gradient-success">
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </form>
          </CardContent>
        </Card>
        {/* Existing Questions Table */}
        {editingQuestions.length > 0 && (
          <Card className="overflow-x-auto">
            <CardHeader>
              <CardTitle>Existing Questions ({editingQuestions.length})</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table className="min-w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead>Question</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Correct Answer</TableHead>
                    <TableHead>Order</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {editingQuestions.map((question) => (
                    <TableRow key={question.id}>
                      <TableCell className="font-medium max-w-xs truncate">{question.question_text}</TableCell>
                      <TableCell>{question.question_type}</TableCell>
                      <TableCell className="font-semibold">{question.correct_answer}</TableCell>
                      <TableCell>{question.order_index}</TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteQuestion(question.id)}
                          className="hover:scale-105 transition-transform"
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )}
</DialogContent>
                          </Dialog>
                          <Button
                            variant="destructive"
                            size="icon"
                            onClick={() => handleDeleteLesson(lesson.id)}
                            className="hover:scale-110 transition-transform"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                    {lessons.length === 0 && (
                      <p className="text-center text-muted-foreground py-8 animate-bounce-in">
                        No lessons yet. Create your first lesson above! 🎓
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="users">
              <Card className="animate-scale-in border-2">
                <CardHeader className="bg-gradient-primary text-primary-foreground rounded-t-lg">
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-2xl">👥</span> Manage Users
                  </CardTitle>
                  <CardDescription className="text-primary-foreground/90">
                    View users and manage admin roles
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead>Display Name</TableHead>
                        <TableHead>XP</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium">{user.username}</TableCell>
                          <TableCell>{user.display_name || "-"}</TableCell>
                          <TableCell>{user.total_xp} ⭐</TableCell>
                          <TableCell>
                            {user.role === "admin" ? (
                              <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
                                <Shield className="w-3 h-3" /> Admin
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-xs">User</span>
                            )}
                          </TableCell>
                          <TableCell className="text-muted-foreground text-sm">
                            {new Date(user.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant={user.role === "admin" ? "destructive" : "outline"}
                              size="sm"
                              onClick={() => handleToggleAdmin(user.id, user.role)}
                              className="hover:scale-105 transition-transform"
                            >
                              {user.role === "admin" ? (
                                <>
                                  <ShieldOff className="w-4 h-4 mr-1" /> Remove Admin
                                </>
                              ) : (
                                <>
                                  <Shield className="w-4 h-4 mr-1" /> Make Admin
                                </>
                              )}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  {users.length === 0 && (
                    <p className="text-center text-muted-foreground py-8">
                      No users found 🔍
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};
export default Admin;