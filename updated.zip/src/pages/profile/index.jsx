import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { ArrowLeft, Save, Trophy, BookOpen, Target, TrendingUp } from "lucide-react";
import { AchievementBadge } from "@/components/AchievementBadge";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts";
import { useRouter } from "next/navigation";

const Profile = () => {
  const navigate = useRouter();
  const [profile, setProfile] = useState(null);
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({
    totalLessons: 0,
    completedLessons: 0,
    achievementsEarned: 0,
    totalAchievements: 0,
  });
  const [activityData, setActivityData] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [userAchievements, setUserAchievements] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);
  const fetchData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate.push("/auth");
        return;
      }
      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();
      if (profileData) {
        setProfile(profileData);
        setDisplayName(profileData.display_name || "");
        setAvatarUrl(profileData.avatar_url || "");
      }
      // Fetch stats
      const [lessonsResult, progressResult, achievementsResult, userAchievementsResult, activityResult] = await Promise.all([
        supabase.from("lessons").select("id"),
        supabase.from("user_progress").select("lesson_id").eq("user_id", user.id).eq("completed", true),
        supabase.from("achievements").select("*"),
        supabase.from("user_achievements").select("*").eq("user_id", user.id),
        supabase.from("user_activity").select("*").eq("user_id", user.id).order("activity_date", { ascending: true }).limit(7),
      ]);
      setStats({
        totalLessons: lessonsResult.data?.length || 0,
        completedLessons: progressResult.data?.length || 0,
        achievementsEarned: userAchievementsResult.data?.length || 0,
        totalAchievements: achievementsResult.data?.length || 0,
      });
      if (achievementsResult.data) setAchievements(achievementsResult.data);
      if (userAchievementsResult.data) setUserAchievements(userAchievementsResult.data);
     
      if (activityResult.data) {
        const formattedData = activityResult.data.map((activity) => ({
          date: new Date(activity.activity_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          xp: activity.xp_earned || 0,
          lessons: activity.lessons_completed || 0,
        }));
        setActivityData(formattedData);
      }
    } catch (error) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };
  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { error } = await supabase
        .from("profiles")
        .update({
          display_name: displayName,
          avatar_url: avatarUrl,
        })
        .eq("id", user.id);
      if (error) throw error;
      toast.success("Profile updated successfully! 🎉");
      fetchData();
    } catch (error) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg animate-bounce-in">Loading your awesome profile... ✨</div>
      </div>
    );
  }
  const progressPercent = stats.totalLessons > 0
    ? (stats.completedLessons / stats.totalLessons) * 100
    : 0;
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-primary/5">
      <div className="container max-w-6xl mx-auto px-4 py-8">
        <div className="animate-fade-in">
          <Button
            variant="ghost"
            onClick={() => navigate.push("/dashboard")}
            className="mb-4 hover:scale-105 transition-transform"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-4xl font-bold mb-2 bg-gradient-primary bg-clip-text text-transparent">
            Your Profile 👤
          </h1>
          <p className="text-muted-foreground mb-8">Manage your info and track your progress</p>
          {/* Profile Edit Section */}
          <Card className="mb-8 hover:shadow-lg transition-all animate-scale-in border-2">
            <CardHeader className="bg-gradient-primary text-primary-foreground rounded-t-lg">
              <CardTitle className="flex items-center gap-2">
                <span className="text-2xl">✏️</span> Edit Profile
              </CardTitle>
              <CardDescription className="text-primary-foreground/90">
                Update your display name and avatar
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-6 items-start">
                <div className="flex flex-col items-center gap-4">
                  <Avatar className="w-32 h-32 ring-4 ring-primary/20 hover:ring-primary/40 transition-all animate-bounce-in">
                    <AvatarImage src={avatarUrl} />
                    <AvatarFallback className="text-4xl bg-gradient-primary text-primary-foreground">
                      {displayName?.[0]?.toUpperCase() || profile?.username?.[0]?.toUpperCase() || "?"}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="flex-1 space-y-4">
                  <div>
                    <Label htmlFor="username" className="text-sm font-semibold">Username (cannot be changed)</Label>
                    <Input
                      id="username"
                      value={profile?.username || ""}
                      disabled
                      className="bg-muted"
                    />
                  </div>
                  <div>
                    <Label htmlFor="displayName" className="text-sm font-semibold">Display Name ✨</Label>
                    <Input
                      id="displayName"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Your awesome name"
                      className="hover:border-primary transition-colors"
                    />
                  </div>
                  <div>
                    <Label htmlFor="avatarUrl" className="text-sm font-semibold">Avatar URL 🖼️</Label>
                    <Input
                      id="avatarUrl"
                      value={avatarUrl}
                      onChange={(e) => setAvatarUrl(e.target.value)}
                      placeholder="https://example.com/avatar.jpg"
                      className="hover:border-primary transition-colors"
                    />
                  </div>
                  <Button
                    onClick={handleSaveProfile}
                    disabled={saving}
                    className="w-full hover:scale-105 transition-transform bg-gradient-primary"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {saving ? "Saving... 💾" : "Save Changes 🚀"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-primary/50">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-accent" />
                  Total XP
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">{profile?.total_xp || 0} 🌟</div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-success/50" style={{ animationDelay: '0.1s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-success" />
                  Lessons Completed
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-success">
                  {stats.completedLessons}/{stats.totalLessons} 📚
                </div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-secondary/50" style={{ animationDelay: '0.2s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Target className="w-4 h-4 text-secondary" />
                  Current Streak
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-secondary">
                  {profile?.current_streak || 0} 🔥
                </div>
              </CardContent>
            </Card>
            <Card className="hover:scale-105 transition-transform animate-fade-in border-2 hover:border-accent/50" style={{ animationDelay: '0.3s' }}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-accent" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-accent">
                  {stats.achievementsEarned}/{stats.totalAchievements} 🏆
                </div>
              </CardContent>
            </Card>
          </div>
          {/* Progress Overview */}
          <Card className="mb-8 animate-scale-in border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Learning Progress 📈
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">Overall Completion</span>
                  <span className="font-bold text-primary">{Math.round(progressPercent)}% 🎯</span>
                </div>
                <Progress value={progressPercent} className="h-4 animate-pulse-glow" />
              </div>
            </CardContent>
          </Card>
          {/* Activity Charts */}
          {activityData.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              <Card className="animate-fade-in border-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">📊</span> XP Earned (Last 7 Days)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={{ xp: { label: "XP", color: "hsl(var(--primary))" } }}>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={activityData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Line type="monotone" dataKey="xp" stroke="hsl(var(--primary))" strokeWidth={3} />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
              <Card className="animate-fade-in border-2" style={{ animationDelay: '0.1s' }}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">📚</span> Lessons Completed (Last 7 Days)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={{ lessons: { label: "Lessons", color: "hsl(var(--success))" } }}>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={activityData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Bar dataKey="lessons" fill="hsl(var(--success))" radius={[8, 8, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>
          )}
          {/* Achievements */}
          <Card className="animate-scale-in border-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-accent" />
                Your Achievements 🏆
              </CardTitle>
              <CardDescription>
                {stats.achievementsEarned} of {stats.totalAchievements} earned - Keep going! 💪
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement) => {
                  const earned = userAchievements.find(
                    (ua) => ua.achievement_id === achievement.id
                  );
                  return (
                    <div key={achievement.id} className="animate-bounce-in hover:scale-105 transition-transform">
                      <AchievementBadge
                        achievement={{
                          ...achievement,
                          earned: !!earned,
                          earned_at: earned?.earned_at,
                        }}
                      />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
export default Profile;