import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Trophy, Medal, Award } from "lucide-react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

const Leaderboard = () => {
  const navigate = useRouter();
  const [leaderboard, setLeaderboard] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      const { data: profilesData } = await supabase
        .from("profiles")
        .select("id, username, total_xp, current_streak")
        .order("total_xp", { ascending: false })
        .limit(50);

      if (profilesData) {
        const rankedData = profilesData.map((profile, index) => ({
          ...profile,
          rank: index + 1,
        }));

        setLeaderboard(rankedData);

        if (user) {
          const userEntry = rankedData.find((p) => p.id === user.id);
          if (userEntry) {
            setCurrentUser(userEntry);
          }
        }
      }
    } catch (error) {
      toast.error(error.message || "Failed to load leaderboard");
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-accent" />;
      case 2:
        return <Medal className="w-6 h-6 text-muted-foreground" />;
      case 3:
        return <Award className="w-6 h-6 text-secondary" />;
      default:
        return null;
    }
  };

  const getRankBadgeColor = (rank) => {
    switch (rank) {
      case 1:
        return "bg-accent text-accent-foreground";
      case 2:
        return "bg-muted-foreground text-white";
      case 3:
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-muted";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading leaderboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => navigate.push("/dashboard")}
          className="mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <Card className="mb-8 bg-gradient-hero text-white border-0">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="w-16 h-16" />
            </div>
            <CardTitle className="text-3xl font-bold">
              Global Leaderboard
            </CardTitle>
            <CardDescription className="text-white/80">
              Compete with learners around the world
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Current User Card */}
        {currentUser && (
          <Card className="mb-6 border-primary border-2">
            <CardHeader>
              <CardTitle className="text-lg">Your Ranking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Badge className={getRankBadgeColor(currentUser.rank || 0)}>
                    #{currentUser.rank}
                  </Badge>
                  <Avatar>
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {currentUser.username.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">{currentUser.username}</div>
                    <div className="text-sm text-muted-foreground">
                      {currentUser.current_streak} day streak
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{currentUser.total_xp}</div>
                  <div className="text-sm text-muted-foreground">XP</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Leaderboard List */}
        <Card>
          <CardHeader>
            <CardTitle>Top Learners</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {leaderboard.map((entry) => (
              <div
                key={entry.id}
                className={`flex items-center justify-between p-4 rounded-lg transition-colors ${
                  entry.id === currentUser?.id
                    ? "bg-primary/10 border border-primary"
                    : "bg-muted hover:bg-muted/80"
                }`}
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className="flex items-center gap-2 min-w-[80px]">
                    {getRankIcon(entry.rank || 0)}
                    <Badge
                      variant="outline"
                      className={
                        entry.rank && entry.rank <= 3
                          ? getRankBadgeColor(entry.rank)
                          : ""
                      }
                    >
                      #{entry.rank}
                    </Badge>
                  </div>
                  <Avatar>
                    <AvatarFallback className="bg-primary text-primary-foreground">
                      {entry.username.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-semibold">{entry.username}</div>
                    <div className="text-sm text-muted-foreground">
                      {entry.current_streak} day streak
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold">{entry.total_xp}</div>
                  <div className="text-sm text-muted-foreground">XP</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Leaderboard;