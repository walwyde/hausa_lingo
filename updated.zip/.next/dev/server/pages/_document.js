var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules_186c80ea._.js")
R.c("server/chunks/ssr/[root-of-the-server]__aa0b05e3._.js")
R.m("[project]/src/pages/_document.js [ssr] (ecmascript)")
module.exports=R.m("[project]/src/pages/_document.js [ssr] (ecmascript)").exports
