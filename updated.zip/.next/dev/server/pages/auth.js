var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/auth.js")
R.c("server/chunks/ssr/node_modules_019cbc36._.js")
R.c("server/chunks/ssr/[root-of-the-server]__4818db33._.js")
R.c("server/chunks/ssr/node_modules_186c80ea._.js")
R.c("server/chunks/ssr/[root-of-the-server]__aa0b05e3._.js")
R.c("server/chunks/ssr/[root-of-the-server]__4b987937._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/src/pages/auth/index.jsx [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/src/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/src/pages/_app.jsx [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/src/pages/auth/index.jsx [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/src/pages/_document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/src/pages/_app.jsx [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
