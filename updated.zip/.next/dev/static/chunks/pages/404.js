__turbopack_load_page_chunks__("/404", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_79b1c0a1._.js",
  "static/chunks/node_modules_next_dist_client_f4b58c85._.js",
  "static/chunks/node_modules_next_dist_ec0ff3d3._.js",
  "static/chunks/node_modules_next_navigation_278dac8a.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_416396d1._.js",
  "static/chunks/[root-of-the-server]__f8c3950c._.js",
  "static/chunks/src_pages_404_2da965e7._.js",
  "static/chunks/turbopack-src_pages_404_d87a707c._.js"
])
