__turbopack_load_page_chunks__("/lesson/[id]", [
  "static/chunks/[root-of-the-server]__e49dab89._.js",
  "static/chunks/node_modules_next_dist_compiled_caaa605a._.js",
  "static/chunks/node_modules_next_dist_shared_lib_79b1c0a1._.js",
  "static/chunks/node_modules_next_dist_client_f4b58c85._.js",
  "static/chunks/node_modules_next_dist_ec0ff3d3._.js",
  "static/chunks/node_modules_next_navigation_278dac8a.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_@supabase_realtime-js_dist_module_ff1c51c7._.js",
  "static/chunks/node_modules_@supabase_storage-js_dist_module_9c628d94._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e0400d86._.js",
  "static/chunks/node_modules_9f6e4ece._.js",
  "static/chunks/src_pages_lesson_[id]_jsx_2da965e7._.js",
  "static/chunks/turbopack-src_pages_lesson_[id]_jsx_9a0d2a3e._.js"
])
