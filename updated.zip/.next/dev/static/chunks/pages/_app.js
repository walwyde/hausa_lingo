__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_8ca6b690._.js",
  "static/chunks/node_modules_next_dist_shared_lib_82dc2e9d._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_6024eba3._.js",
  "static/chunks/node_modules_react_e3593a73._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_2b5e0eb3.js",
  "static/chunks/node_modules_react-dom_8a8085df._.js",
  "static/chunks/node_modules_5ec44f59._.js",
  "static/chunks/[root-of-the-server]__ac941a29._.js",
  "static/chunks/src_styles_globals_5bb75e7e.css",
  "static/chunks/src_pages__app_2da965e7._.js",
  "static/chunks/turbopack-src_pages__app_c8b1ef7a._.js"
])
