self.__BUILD_MANIFEST = {
  "/": [
    "static/chunks/pages/index.js"
  ],
  "/admin": [
    "static/chunks/pages/admin.js"
  ],
  "/auth": [
    "static/chunks/pages/auth.js"
  ],
  "/dashboard": [
    "static/chunks/pages/dashboard.js"
  ],
  "/leaderboard": [
    "static/chunks/pages/leaderboard.js"
  ],
  "/lesson/[id]": [
    "static/chunks/pages/lesson/[id].js"
  ],
  "/profile": [
    "static/chunks/pages/profile.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/admin",
    "/api/hello",
    "/auth",
    "/dashboard",
    "/leaderboard",
    "/lesson/[id]",
    "/profile"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()